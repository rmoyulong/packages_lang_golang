package Slim::Plugin::UPnP::MediaRenderer::ProtocolHandler;

# Logitech Media Server Copyright 2003-2024 Logitech.
# Lyrion Music Server Copyright 2024-2026 Lyrion Community.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Player::Protocols::HTTP);

use File::Temp ();
use Audio::Scan;

use Slim::Utils::Cache;
use Slim::Utils::Errno;
use Slim::Utils::Log;
use Slim::Utils::Misc;

use Slim::Plugin::UPnP::MediaRenderer::AVTransport ();

use constant MAX_RAW_READ => 32768;

# How much of the (already dechunked/decoded) audio stream to initially buffer in
# _scanBitrateFeed() below before giving up on determining its bitrate, matching
# Slim::Utils::Scanner::Remote::parseAudioStream()'s default buffer size.
use constant SCAN_READ_BYTES => 128 * 1024;
# How many bytes of audio frames past the end of an ID3v2 tag to also buffer
# to have something to determine the bitrate from.
use constant SCAN_READ_PAST_ID3 => 16 * 1024;

my $log = logger('plugin.upnp');

sub isRemote { 1 }

# We are caching the cover image on our own
sub shouldCacheImage { 0 }

# Always proxy through the server so the outgoing connection to the source uses
# the same IP address that was published for this player via UPnP, and so we can
# use the HTTP/1.1 + chunked transfer-encoding capable persistent connection.
sub canDirectStream { 0 }

sub _normalizeRequestToHttp11 {
	my ( $class, $request ) = @_;
	$request =~ s/^(\S+ \S+) HTTP\/1\.0\r\n/$1 HTTP\/1.1\r\n/;
	return $request;
}

# The server's own outgoing connection to the DLNA source (see canDirectStream
# above) is built and sent by this class, never handed to player firmware, so
# upgrading it to HTTP/1.1 requires no firmware support. HTTP/1.1 is required
# to allow the source to reply with "Transfer-Encoding: chunked" (chunked
# responses are undefined in HTTP/1.0).
sub requestString {
	my $class = shift;
	my $request = $class->SUPER::requestString(@_);
	return $class->_normalizeRequestToHttp11($request);
}

# This primary connection is always read as a raw byte stream by
# Slim::Player::Protocols::HTTP (see readPersistentChunk), with no knowledge of
# HTTP chunked Transfer-Encoding. If the source replied with chunked encoding
# (detected below), transparently strip the chunk framing here before the
# bytes reach the audio decoder.
#
# Slim::Player::Protocols::HTTP::response() re-parses $request into the
# HTTP::Request object it keeps for the persistent/proxied connection, so its
# protocol is picked up straight from the request line. Rewrite that line to
# HTTP/1.1 here (same substitution as requestString() above) instead of
# patching the base class, keeping the HTTP/1.1 upgrade local to this plugin.
sub response {
	my $self = shift;
	my ($args, $request, @headers) = @_;

	$request = $self->_normalizeRequestToHttp11($request);

	if ( grep { /^Transfer-Encoding\s*:\s*chunked/i } @headers ) {
		${*$self}{'_dechunk'} = { raw => '', out => '', pending => undef, eof => 0 };
		main::INFOLOG && $log->info('Response is chunked, decoding Transfer-Encoding on the fly');
	}

	return $self->SUPER::response($args, $request, @headers);
}

sub _sysread {
	my $self = $_[0];

	my $ret = $self->_sysread_impl( $_[1], $_[2], $_[3] );

	# note: we'll do an on-the-fly bitrate scan as data is read if required
	if ( $ret ) {
		$self->_scanBitrateFeed( substr( $_[1], $_[3] || 0, $ret ) );
	}
	elsif ( defined $ret ) {
		# graceful stream end - finalize a still-pending scan with whatever we have
		$self->_scanBitrateFeed( undef, 1 );
	}

	return $ret;
}

sub _sysread_impl {
	my $self    = $_[0];
	my $dechunk = ${*$self}{'_dechunk'} || return $self->SUPER::_sysread($_[1], $_[2], $_[3]);

	my $wantLen = $_[2];
	my $offset  = $_[3] || 0;

	if ( !length $dechunk->{'out'} && !$dechunk->{'eof'} ) {
		my $raw = $self->SUPER::_sysread( my $buf, MAX_RAW_READ, 0 );

		# propagate "no data yet" (EWOULDBLOCK/EINTR) and real read errors as-is
		if ( !$raw ) {
			# A closed socket ($raw defined as 0) or a hard read error (undef $raw
			# with an errno other than "try again") before we ever saw the chunk
			# stream's own 0-size terminator below means the source dropped the
			# connection rather than ending the stream gracefully. Undo the
			# isLive(0) set by parseHeaders() so StreamingController::_RetryOrNext()
			# reconnects, same as it would for any other isLive stream that got cut off.
			if ( ( defined($raw) || ( $! != EWOULDBLOCK && $! != EINTR ) ) && ( my $song = ${*$self}{'song'} ) ) {
				$song->isLive(1);
			}
			return $raw;
		}

		$dechunk->{'raw'} .= $buf;

		# extract as many complete chunks as are currently buffered
		while (1) {
			if ( !defined $dechunk->{'pending'} ) {
				last unless $dechunk->{'raw'} =~ s/^([0-9A-Fa-f]+)[^\r\n]*\r\n//;
				my $size = hex($1);

				if ( !$size ) {
					$dechunk->{'eof'} = 1;
					last;
				}

				$dechunk->{'pending'} = $size;
			}

			last if length( $dechunk->{'raw'} ) < $dechunk->{'pending'} + 2;

			$dechunk->{'out'} .= substr( $dechunk->{'raw'}, 0, $dechunk->{'pending'}, '' );
			substr( $dechunk->{'raw'}, 0, 2, '' ); # discard the CRLF following each chunk's data
			$dechunk->{'pending'} = undef;
		}
	}

	if ( length $dechunk->{'out'} ) {
		$_[1] = '' unless defined $_[1];
		substr( $_[1], $offset ) = substr( $dechunk->{'out'}, 0, $wantLen, '' );
		return length($_[1]) - $offset;
	}

	return 0 if $dechunk->{'eof'};

	# no complete chunk decoded yet, ask caller to retry shortly
	$_[1] = '' unless $offset;
	$! = EWOULDBLOCK;
	return undef;
}

sub getFormatForURL {
	my $class = shift;
	my $url = shift;

    my $meta = Slim::Plugin::UPnP::MediaRenderer::AVTransport->trackMetaFor($url);
    return ( $meta && exists $meta->{ct} ) ? $meta->{ct} : undef;
}

sub canSeek {
	my ( $class, $client, $song ) = @_;

	return 1 unless $song;

	my $meta = Slim::Plugin::UPnP::MediaRenderer::AVTransport->trackMetaFor( $song->currentTrack->url );
	return ( $meta && exists $meta->{seekable} ) ? $meta->{seekable} : 1;
}

sub canSeekError { return ( 'SEEK_ERROR_TYPE_NOT_SUPPORTED', 'UPnP/DLNA' ); }

# To support remote streaming (synced players), we need to subclass Protocols::HTTP
sub new {
	my $class  = shift;
	my $args   = shift;

	my $client    = $args->{client};
	my $song      = $args->{song};
	my $streamUrl = $song->streamUrl() || return;

	main::DEBUGLOG && $log->is_debug && $log->debug( 'Remote streaming UPnP track: ' . $streamUrl );

	my $sock = $class->SUPER::new( {
		url     => $streamUrl,
		song    => $args->{song},
		client  => $client,
		bitrate => $song->bitrate() || 128_000,
	} ) || return;

	my $meta = Slim::Plugin::UPnP::MediaRenderer::AVTransport->trackMetaFor( $song->currentTrack->url );
	${*$sock}{contentType} = ( $meta && $meta->{res}->{mime} ) || 'audio/mpeg';

	return $sock;
}

# Avoid scanning here. Only scan on-the-fly when the track is actually played
# and the bitrate is still unknown, see _scanBitrateInit and _scanBitrateFeed.
sub scanUrl {
	my ($class, $url, $args) = @_;

	# $url is a synthetic per-playlist-entry id (see AVTransport::_newTrackId),
	# looked up via AVTransport's client-independent registry rather than
	# $args->{client}'s pluginData: in a sync group, this is called with the
	# sync-group's master client, which may not be the client this UPnP
	# session's state was stored on.
	my $meta = Slim::Plugin::UPnP::MediaRenderer::AVTransport->trackMetaFor($url);

	if ( ref($meta) eq 'HASH' && ( my $uri = $meta->{res}->{content} ) ) {
		$args->{song}->streamUrl($uri);
	}

	$args->{cb}->($args->{song}->currentTrack());
}


# Formats we can determine the bitrate of on the fly
my %AUDIO_SCAN_FORMAT = (
	mp3 => [ 'mp3',  \&_scanMP3Info ],
	wav => [ 'wav',  \&_scanPCMInfo ],
	aif => [ 'aif',  \&_scanPCMInfo ],
	ogg => [ 'ogg',  \&_scanVorbisInfo ],
	ops => [ 'opus', \&_scanVorbisInfo ],
);

sub _scanMP3Info {
	my $info = shift;
	return ( $info->{bitrate}, $info->{vbr} );
}

sub _scanPCMInfo {
	my $info = shift;
	return ( $info->{bitrate}, 0 );
}

sub _scanVorbisInfo {
	my $info = shift;

	my $vbr = 0;
	if ( defined $info->{bitrate_upper} && defined $info->{bitrate_lower} ) {
		$vbr = $info->{bitrate_upper} != $info->{bitrate_lower} ? 1 : 0;
	}

	my $bitrate = $info->{bitrate_average} || $info->{bitrate_nominal};

	return ( $bitrate, $vbr );
}

sub _scanBitrateInit {
	my $self = shift;

	# check preconditions

	if ( my $range = ${*$self}{'contentRange'} ) {
		my ($first) = $range =~ /^(\d+)-/;
		return 0 if $first;
	}
	return 0 if ${*$self}{'metaInterval'};

	my $song = ${*$self}{'song'} || return 0;
	return 0 if Slim::Music::Info::getBitrate( $song->currentTrack->url );

	my $type = Slim::Music::Info::contentType( $song->currentTrack->url ) || return 0;
	my $format = $AUDIO_SCAN_FORMAT{$type} || return 0;

	# all preconditions met, so start scanning on the fly

	main::DEBUGLOG && $log->is_debug && $log->debug( 'Scanning ' . $song->currentTrack->url . ' on the fly for bitrate' );

	return {
		fh        => File::Temp->new( DIR => Slim::Utils::Misc::getTempDir ),
		len       => 0,
		scanLen   => SCAN_READ_BYTES,
		url       => $song->currentTrack->url,
		type      => $type,
		asFormat  => $format->[0],
		extractor => $format->[1],
	};
}

# Tees received data into a temp file until enough has been buffered
# (or the stream ends) to run it through Audio::Scan->scan_fh().
# This is similar to Slim::Utils::Scanner::Remote::parseAudioStream(), but
# we won't open a separate connection for this.
sub _scanBitrateFeed {
	my ( $self, $data, $eof ) = @_;

	my $scan = ${*$self}{'_bitrateScan'};

	# undef means "not yet decided", 0 means "decided: nothing to do"
	if ( !defined $scan ) {
		$scan = ${*$self}{'_bitrateScan'} = $self->_scanBitrateInit;
	}

	return unless $scan;

	if ( defined $data && length $data ) {
		if ( !$scan->{len} && $scan->{type} eq 'mp3' && $data =~ /^ID3/ ) {
			# ID3v2 tag on the very first chunk - grow the buffer to cover
			# the full tag (which may hold a sizeable embedded cover image)
			# plus some trailing audio frames to determine the bitrate from,
			# same as Slim::Utils::Scanner::Remote::parseAudioStream() does.

			# get ID3v2 tag length from bytes 7-10
			my $id3size = 0;
			for my $b ( unpack 'C4', substr( $data, 6, 4 ) ) {
				$id3size = ($id3size << 7) + $b;
			}
			$id3size += 10;

			$scan->{scanLen} = $id3size + SCAN_READ_PAST_ID3;

			main::DEBUGLOG && $log->is_debug && $log->debug( "ID3v2 tag detected, will buffer $scan->{scanLen} bytes for $scan->{url}" );
		}

		$scan->{fh}->write( $data, length $data );
		$scan->{len} += length $data;
	}

	return if !$eof && $scan->{len} < $scan->{scanLen};

	# enough data buffered (or stream ended) - scan once and stop
	${*$self}{'_bitrateScan'} = 0;

	$scan->{fh}->seek( 0, 0 );

	# we only want the bitrate here, not tags or embedded artwork
	local $ENV{AUDIO_SCAN_NO_ARTWORK} = 1;

	my $info = eval { Audio::Scan->scan_fh( $scan->{asFormat}, $scan->{fh} )->{info} };

	my ( $bitrate, $vbr );

	if ( $@ ) {
		$log->error("Unable to scan bitrate for $scan->{url}: $@");
	}
	elsif ( $info ) {
		( $bitrate, $vbr ) = $scan->{extractor}->($info);
	}

	if ( $bitrate && $bitrate > 0 ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Scanned bitrate for $scan->{url}: $bitrate");

		Slim::Music::Info::setBitrate( $scan->{url}, $bitrate, $vbr );
		if ( my $song = ${*$self}{'song'} ) {
			$song->bitrate($bitrate);
		}
		# Update the playlist time so the web will refresh, etc
		# this is copied from Slim::Plugin::RemoteLibrary::ProtocolHandler::_gotMetadata
		if ( my $client = ${*$self}{'client'} ) {
			$client->currentPlaylistUpdateTime( Time::HiRes::time() );
			Slim::Control::Request::notifyFromArray( $client, ['newmetadata'] );
		}
	}
}

sub audioScrobblerSource { 'P' }

# Slim::Player::Protocols::HTTP::parseHeaders() sets isLive(1) whenever no
# Content-Length is known, which is also the case for chunked-encoded streams.
#
# StreamingController::_RetryOrNext() treats isLive tracks as infinite radio
# and, once played for more than 10s, tries to reconnect to the same URI.
# DLNA/UPnP tracks are finite, discrete tracks despite lacking a known length,
# so we override parseHeaders() to set isLive(0) for them instead.
#
# Only chunked responses get this treatment: they're the only ones where
# _sysread() can tell a graceful stream end (its own EOF chunk) apart from a
# genuine connection abort, and re-arms isLive(1) itself when it sees the
# latter, so a real disconnect still triggers a reconnect.
# For any other response (fixed Content-Length, or no chunking), leave
# isLive exactly as the base class set it.
sub parseHeaders {
        my $self = shift;
        my $ret  = $self->SUPER::parseHeaders(@_);

        if ( grep { /^Transfer-Encoding\s*:\s*chunked/i } @_ ) {
                if ( my $song = ${*$self}{'song'} ) {
                        $song->isLive(0);
                }
        }

        return $ret;
}

# XXX parseDirectHeaders, needed?

# XXX seek data, using res@size, res@duration instead of bitrate

sub isRepeatingStream {
	my (undef, $song) = @_;

	return 0; # XXX playlists, REPEAT_ONE, REPEAT_ALL, SHUFFLE
}

# XXX getNextTrack (playlists, next track)

sub getMetadataFor {
	my ( $class, $client, $url ) = @_;

	# This returns metadata for any tracks added to the playlist via the plugin.
	# $url is a synthetic per-playlist-entry id (see AVTransport::_newTrackId),
	# looked up via AVTransport's client-independent registry rather than
	# $client's pluginData: in a sync group, this is called with the sync-group's
	# master client, which may not be the client this UPnP session's state was
	# stored on.
	my $meta = Slim::Plugin::UPnP::MediaRenderer::AVTransport->trackMetaFor($url) || {};

	# support Icy Metadata updates
	my $title = Slim::Music::Info::getCurrentTitle( $client, $url );

	# may reflect a bitrate determined on the fly (see _scanBitrateFeed)
	my $bitrate = Slim::Music::Info::getCurrentBitrate($url) || 0;
	my $duration = Slim::Music::Info::getDuration($url) || 0;

	my $type = uc( Slim::Music::Info::contentType($url) || '' ) . ' (UPnP/DLNA)'; 

	main::DEBUGLOG && $log->is_debug && $log->debug( 'Metadata returned for  ' . $title );
	return {
		artist   => $meta->{artist},
		album    => $meta->{album},
		title    => $title,
		type     => $type,
		bitrate  => $bitrate,
		duration => $duration,
		icon     => '', # XXX default icon
		cover    => $meta->{cover} || '', # XXX default
	};
}


1;
