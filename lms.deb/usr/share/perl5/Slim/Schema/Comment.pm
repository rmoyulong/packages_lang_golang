package Slim::Schema::Comment;


use strict;
use base 'Slim::Schema::DBI';

{
	my $class = __PACKAGE__;

	$class->table('comments');

	$class->add_columns(
		id => { is_auto_increment => 1 },
		qw(track value),
	);

	$class->set_primary_key('id');

	$class->belongs_to(track => 'Slim::Schema::Track');

	$class->utf8_columns(qw/value/);
}

1;

__END__


# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:
